
void main()
{
	int i;
	i=10;
	for(i=0;i<10;i++)
	{
		i=i+10;
	}
	i--;
	a++;
}
