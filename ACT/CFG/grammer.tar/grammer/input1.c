void main()
{
	int i;
	for(i=0;i<10;i++)
	{
		i=i+1;

	}
	a=1;
    	while(a>b)
	{
		a=1;
		i++;
	}
	while(a>b)
	{
		a=1;
		i++;
	}
	b=0;
	if(a>b)
	{
		i++;
		j++;
		k--;
	}
	else
	{	
		i--;
	}
	print("hello");
}
void print()
{
	printf("hello world..");
}
