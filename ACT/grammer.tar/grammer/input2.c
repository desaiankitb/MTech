void main()
{
	print();
}
print()
{
	int a,b;
	printf("hello");
	a = b;
}
