void main()
{
	print();
}
print()
{
	int x=10;
	y=0;
	while(a==b)
	{
		a++;
		b--;
	}
	if(a==0)
	{
		a--;
	}
	a++;
}
