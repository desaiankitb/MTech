#include<stdio.h>
#include<math.h>
void printdata(int a,int b)
{
	printf("a=%d\nb=%d\n",a,b);
}

int main(int argc,int argv[])
{
	int a=10,b=5;
	printdata(a,b);
	//printf("a=%d\nb=%d\n",a,b);
	return 0;
}
